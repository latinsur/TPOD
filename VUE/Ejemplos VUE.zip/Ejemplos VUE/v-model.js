var myObject = new Vue({
  el: '#app',
  data: { message: 'Hello Vue!' }
})
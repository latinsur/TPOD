<template>
    <div id="about" class="container active">
        <h1> about </h1>
    </div>
</template>

<script>
    module.exports = {
        data = {}
    }
</script>
 
<style>
    .about {
        background-color: red;
    }
</style>
